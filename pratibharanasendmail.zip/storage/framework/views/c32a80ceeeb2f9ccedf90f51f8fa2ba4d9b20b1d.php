<p>Hi, This is : <?php echo e($maildata['name']); ?></p>
<p>My  EmailMail Adress is  : <?php echo e($maildata['email']); ?></p>
<p>I have some query like  : <?php echo e($maildata['message']); ?>.</p>
<p>It would be appriciative, if you gone through this feedback.Attaching you the issues I am facing</p>
<img src= "<?php echo e($message->embed(storage_path('app/'. $maildata['image']))); ?>" width= "400"/><?php /**PATH E:\xampp\htdocs\pratibhasendmail\resources\views/email_template.blade.php ENDPATH**/ ?>